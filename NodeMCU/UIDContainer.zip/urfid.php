<?php
	$cardid = $_POST["cardid"];
	$Write="<?php $" . "cardid='" . $cardid . "'; " . "echo $" . "cardid;" . " ?>";
	file_put_contents('UIDContainer.php', $Write);

	//FIRST CHECK IF CARDID EXIST IN RFID TABLE
	//IF IT EXIST IN RFID TABLE CHECK IF LOG_BOOK TABLE HAS THE RFID/CARDID (RFID, TIMEIN(DATE), TIMEOUT)
	//IF NO RESULT SAVE THEN ADD TIME IN RECORD (DATE/TIME)
	//IF HAS RESULT UPDATE THE TIMEOUT RECORD OF THE DATA
?>