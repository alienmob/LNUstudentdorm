<?php
	$Write="<?php $" . "cardid=''; " . "echo $" . "cardid;" . " ?>";
	file_put_contents('UIDContainer.php',$Write);
?>

<!-- Edit -->
<div class="modal fade" id="newidmodal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span></button>
              <h4 class="modal-title"><b>Update Profile</b></h4>
            </div>
            <div class="modal-body">
              <form class="form-horizontal" method="POST" action="profile_update.php?return=<?php echo basename($_SERVER['PHP_SELF']); ?>" enctype="multipart/form-data">
                <!-- <input type="hidden" class="studid" name="id"> -->
                <div class="form-group">
                    <label for="id" class="col-sm-3 control-label">RFID:</label>
                    <div class="col-sm-6">
                      <textarea name="id" id="getUID" class="form-control" placeholder="Please Scan your Card / Key Chain to display ID" rows="1" required></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-default btn-rounded pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
              <button type="submit" class="btn btn-success btn-rounded" name="save"><i class="fa fa-check-square-o"></i> Update</button>
              </form>
            </div>
        </div>
    </div>
</div>

<script>
  $(document).ready(function(){
      $("#getUID").load("UIDContainer.php");
    setInterval(function() {
      $("#getUID").load("UIDContainer.php");
    }, 600);
	});
</script>